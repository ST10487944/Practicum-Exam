package za.ac.iie.musicworld

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {

    private lateinit var songs: ArrayList<String>
    private lateinit var artists: ArrayList<String>
    private lateinit var ratings: ArrayList<Int>
    private lateinit var comments: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val songlistView = findViewById<ListView>(R.id.songListView)
        val avgRating = findViewById<TextView>(R.id.avgRating)
        val btnBack = findViewById<Button>(R.id.btnBack)

        songs = intent.getStringArrayListExtra("songs") ?: arrayListOf("Peekaboo", "Water", "Prove it", "Rewrite the Stars")
        artists = intent.getStringArrayListExtra("artists") ?: arrayListOf("Kendrick Lamar", "Tyla", "21 Savage", "James Arthur")
        ratings = intent.getIntegerArrayListExtra("ratings") ?: arrayListOf(4, 1, 2, 3)
        comments = intent.getStringArrayListExtra("comments") ?: arrayListOf("Rap", "Dance Song", "Best Love Song", "Memories")

        val displayList = ArrayList<String>()
        for (i in songs.indices) {
            displayList.add("Song: ${songs [i]}, Artist: ${artists[i]}, Rating: ${ratings[i]}, Comment: ${comments[i]}")
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        songlistView.adapter = adapter

        if (ratings.isNotEmpty()) {
            val avg = ratings.sum().toDouble() / ratings.size
            avgRating.text = "Average Rating: %.2f".format(avg)
        } else {
            avgRating.text = "No ratings yet."
        }

        btnBack.setOnClickListener {
            finish()
        }
    }
}