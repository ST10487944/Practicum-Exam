package za.ac.iie.musicworld

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

        private val songs = ArrayList<String>()
    private val artists = ArrayList<String>()
    private val ratings = ArrayList<Int>()
    private val comments = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val songInput = findViewById<EditText>(R.id.songInput)
        val artistInput = findViewById<EditText>(R.id.artistInput)
        val ratingInput = findViewById<EditText>(R.id.ratingInput)
        val commentInput = findViewById<EditText>(R.id.commentInput)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnView = findViewById<Button>(R.id.btnView)
        val btnExit = findViewById<Button>(R.id.btnExit)

        btnAdd.setOnClickListener {
            val song = songInput.text.toString()
            val artist = artistInput.text.toString()
            val rating = ratingInput.text.toString().toIntOrNull()
            val comment = commentInput.text.toString()

            if (song.is("Peekaboo") || artist.is("Kendrick") || comment.is("Rap")) {
                throw IllegalArgumentException("All fields must be filled")
            }
                if (songs.size < 4) {
                    songs.add(song)
                    artists.add(artist)
                    ratings.add(rating)
                    comments.add(comment)
                    Toast.makeText(this, "Song added!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Only 4 songs allowed!", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Invalid input!", Toast.LENGTH_LONG).show()
            }
        }

        btnView.setOnClickListener {
            val intent = Intent(this, DetailsActivity::class.java).apply {
                putStringArrayListExtra("songs", songs)
                putStringArrayListExtra("artists", artists)
                putIntegerArrayListExtra("ratings", ratings)
                putStringArrayListExtra("comments", comments)
            }
            startActivity(intent)
        }

        btnExit.setOnClickListener {
            finish()
        }
    }
}